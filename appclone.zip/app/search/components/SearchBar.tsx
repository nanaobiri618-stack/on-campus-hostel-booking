// app/search/components/SearchBar.tsx
"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

type Props = { mode?: "landing" | "results" };

export function SearchBar({ mode = "results" }: Props) {
  const router = useRouter();
  const params = useSearchParams();

  const [campus, setCampus] = useState(params.get("campus") ?? "");
  const [min, setMin] = useState(params.get("min") ?? "");
  const [max, setMax] = useState(params.get("max") ?? "");
  const [gender, setGender] = useState(params.get("gender") ?? "");
  const [date, setDate] = useState(params.get("date") ?? "");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = new URLSearchParams({
      ...(campus && { campus }),
      ...(min && { min }),
      ...(max && { max }),
      ...(gender && { gender }),
      ...(date && { date }),
    });
    router.push(`/search?${q.toString()}`);
  };

  const wrapper = mode === "landing" ? "max-w-3xl mx-auto" : "";

  return (
    <form onSubmit={onSubmit} className={`grid md:grid-cols-5 gap-3 ${wrapper}`} aria-label="Find hostels">
      <input
        className="border rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-600/20"
        placeholder="Campus or City (e.g., KNUST)"
        value={campus}
        onChange={(e) => setCampus(e.target.value)}
        aria-label="Campus or city"
      />
      <input
        className="border rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-600/20"
        placeholder="Min (GHS)"
        inputMode="numeric"
        value={min}
        onChange={(e) => setMin(e.target.value)}
        aria-label="Minimum price"
      />
      <input
        className="border rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-600/20"
        placeholder="Max (GHS)"
        inputMode="numeric"
        value={max}
        onChange={(e) => setMax(e.target.value)}
        aria-label="Maximum price"
      />
      <select
        className="border rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-600/20"
        value={gender}
        onChange={(e) => setGender(e.target.value)}
        aria-label="Gender preference"
      >
        <option value="">Any Gender</option>
        <option value="female">Female‑only</option>
        <option value="male">Male‑only</option>
        <option value="mixed">Mixed</option>
      </select>
      <input
        className="border rounded px-3 py-2 outline-none focus:ring-2 focus:ring-blue-600/20"
        type="date"
        value={date}
        onChange={(e) => setDate(e.target.value)}
        aria-label="Move-in date"
      />

      <button
        type="submit"
        className="md:col-span-5 rounded bg-blue-600 px-4 py-2 font-semibold text-white transition hover:bg-blue-700"
      >
        Search Hostels
      </button>
    </form>
  );
}