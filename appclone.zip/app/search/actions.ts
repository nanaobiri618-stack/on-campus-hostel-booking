// app/search/actions.ts
"use server";

import { mockHostels } from "@/lib/data-source";
import type { SearchQuery, Hostel } from "./types";

/**
 * Filters hostels by campus/city, price range, and gender.
 * Then sorts results by price ascending.
 */
export async function getHostels(q: SearchQuery): Promise<Hostel[]> {
  let data = mockHostels;

  if (q.campus) {
    const c = q.campus.toLowerCase();
    data = data.filter(
      (h) =>
        h.campus.toLowerCase().includes(c) ||
        h.city.toLowerCase().includes(c)
    );
  }

  if (q.min) data = data.filter((h) => h.price >= q.min);
  if (q.max) data = data.filter((h) => h.price <= q.max);

  if (q.gender)
    data = data.filter(
      (h) => h.gender === q.gender || h.gender === "mixed"
    );

  return data.sort((a, b) => a.price - b.price);
}