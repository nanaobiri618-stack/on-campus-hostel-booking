// app/(marketing)/page.tsx
import type { Metadata } from "next";
import { Suspense } from "react";
import { SearchBar } from "../search/components/SearchBar";

export const metadata: Metadata = {
  title: "On Campus Ghana — Find Verified Student Hostels Fast",
  description:
    "Search and book verified student hostels across Ghana by campus, budget, and preferences. Secure payments, real-time alerts, and a stress-free experience.",
  openGraph: {
    title: "On Campus Ghana — Find Verified Student Hostels Fast",
    description:
      "Search and book verified student hostels across Ghana by campus, budget, and preferences. Secure payments, real-time alerts, and a stress-free experience.",
    url: "https://oncampus.example.com/",
    siteName: "On Campus Ghana",
    images: [{ url: "/images/og-hero.png", width: 1200, height: 630, alt: "On Campus Ghana" }],
    locale: "en_GH",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "On Campus Ghana — Find Verified Student Hostels Fast",
    description:
      "Search & book verified student hostels by campus and budget. Secure payments and real-time alerts.",
    images: ["/images/og-hero.png"],
  },
};

export default function LandingPage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-10 lg:py-16">
      {/* HERO */}
      <section
        className="relative overflow-hidden rounded-2xl border border-blue-100/60 bg-gradient-to-br from-blue-50 via-white to-sky-50"
        aria-labelledby="hero-title"
      >
        {/* subtle decorative glows */}
        <div
          aria-hidden
          className="pointer-events-none absolute -top-24 -right-24 h-80 w-80 rounded-full bg-blue-200/30 blur-3xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -bottom-28 -left-28 h-80 w-80 rounded-full bg-emerald-200/30 blur-3xl"
        />
        <div className="relative z-10 px-5 sm:px-10 py-10 lg:py-16 text-center">
          <h1
            id="hero-title"
            className="text-3xl sm:text-5xl/tight font-extrabold tracking-tight text-gray-900"
          >
            Find Your Perfect Hostel—Fast, Easy &amp; Stress‑Free
          </h1>
          <p className="mt-4 text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
            Search verified hostels by campus, budget, and preferences. Book securely and get
            real‑time updates—no surprises.
          </p>

          {/* Inline Search */}
          <div className="mt-8 sm:mt-10">
            <Suspense fallback={<div className="text-gray-500">Loading search…</div>}>
              <SearchBar mode="landing" />
            </Suspense>
            <p className="mt-2 text-xs text-gray-500">
              Tip: try “KNUST”, “Legon”, “Sunyani”, or “Kumasi”.
            </p>
          </div>

          {/* Trust badges */}
          <ul
            className="mt-8 sm:mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-gray-600"
            aria-label="Platform assurances"
          >
            <li className="flex items-center gap-2">
              <span aria-hidden className="inline-block h-2.5 w-2.5 rounded-full bg-emerald-500" />
              Verified Listings
            </li>
            <li className="flex items-center gap-2">
              <span aria-hidden className="inline-block h-2.5 w-2.5 rounded-full bg-blue-600" />
              Secure Payments
            </li>
            <li className="flex items-center gap-2">
              <span aria-hidden className="inline-block h-2.5 w-2.5 rounded-full bg-amber-500" />
              Real‑Time Alerts
            </li>
          </ul>
        </div>
      </section>

      {/* Features */}
      <section className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <Feature
          title="Smart Filters"
          description="Filter by price, gender preference, amenities, and proximity to your campus."
          icon={<span className="text-2xl">🎯</span>}
        />
        <Feature
          title="Instant Updates"
          description="Track availability and booking status as it changes—stay ahead of the rush."
          icon={<span className="text-2xl">⚡</span>}
        />
        <Feature
          title="Owner Tools"
          description="Hostel owners can list properties, manage rooms, and receive payouts easily."
          icon={<span className="text-2xl">🛠️</span>}
        />
      </section>

      {/* Secondary CTAs (optional) */}
      <section
        className="mt-12 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-xl border p-5"
        aria-label="Get the app"
      >
        <div>
          <h2 className="text-lg font-semibold">Get the App</h2>
          <p className="text-sm text-gray-600">
            Manage bookings and alerts on the go. iOS and Android supported.
          </p>
        </div>
        <div className="flex gap-3">
          <a
            href="#"
            className="rounded-md bg-gray-900 px-4 py-2 text-white text-sm hover:bg-black/85"
            aria-label="Download on the App Store (coming soon)"
          >
             App Store
          </a>
          <a
            href="#"
            className="rounded-md bg-green-600 px-4 py-2 text-white text-sm hover:bg-green-700"
            aria-label="Get it on Google Play (coming soon)"
          >
            ▶ Google Play
          </a>
        </div>
      </section>

      <section
        className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-xl border p-5"
        aria-label="List your hostel"
      >
        <div>
          <h2 className="text-lg font-semibold">Are you a Hostel Owner?</h2>
        </div>
        <div>
          <a
            href="/owners"
            className="rounded-md bg-blue-600 px-4 py-2 text-white text-sm font-semibold hover:bg-blue-700"
          >
            List Your Hostel
          </a>
        </div>
      </section>
    </main>
  );
}

function Feature({
  title,
  description,
  icon,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
}) {
  return (
    <article className="rounded-xl border p-5 transition hover:shadow-md">
      <div className="flex items-center gap-3">
        {icon}
        <h3 className="text-base font-semibold">{title}</h3>
      </div>
      <p className="mt-2 text-sm text-gray-600">{description}</p>
    </article>
  );
}