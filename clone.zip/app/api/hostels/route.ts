// app/api/hostels/route.ts
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

// Avoid Next caching
export const dynamic = 'force-dynamic';

// Force Node.js runtime (Prisma does not work on Edge runtime)
export const runtime = 'nodejs';

// --- Prisma singleton to avoid too many connections in dev ---
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['warn', 'error'], // add 'query' temporarily if you need to debug
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
// -------------------------------------------------------------

export async function GET() {
  try {
    const hostels = await prisma.hostel.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(hostels, { status: 200 });
  } catch (error) {
    console.error('Fetch Error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch hostels' },
      { status: 500 }
    );
  }
}