"use client";

import React, { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import { SearchX, Database, MapPin } from "lucide-react";
import { SearchBar } from "./components/SearchBar";
import { mockHostels } from "../../lib/data-source"; 
import type { SearchQuery, Hostel } from "./types";

// --- SEARCH ALGORITHM LOGIC ---
export async function getFilteredHostels(q: SearchQuery, rawData: Hostel[]): Promise<Hostel[]> {
  let data = [...rawData];

  if (q.campus) {
    const c = q.campus.toLowerCase();
    data = data.filter(
      (h) =>
        h.campus.toLowerCase().includes(c) ||
        (h.city && h.city.toLowerCase().includes(c))
    );
  }

  if (q.min) {
    const minVal = Number(q.min);
    if (!isNaN(minVal)) data = data.filter((h) => Number(h.price) >= minVal);
  }
  
  if (q.max) {
    const maxVal = Number(q.max);
    if (!isNaN(maxVal)) data = data.filter((h) => Number(h.price) <= maxVal);
  }

  if (q.gender && q.gender !== "") {
    data = data.filter(
      (h) => h.gender === q.gender || h.gender === "mixed"
    );
  }

  return data.sort((a, b) => Number(a.price) - Number(b.price));
}

export default function SearchResultsPage() {
  const [hostels, setHostels] = useState<Hostel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // --- FETCH FROM DATABASE LOGIC ---
  async function fetchHostels() {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch('/api/hostels');
      if (!response.ok) throw new Error("Database connection failed");
      const data = await response.json();
      
      // If database is empty, we fall back to mockHostels for testing, 
      // otherwise we use the real database data.
      const sourceData = data.length > 0 ? data : (mockHostels as any[] as Hostel[]);
      setHostels(sourceData);
    } catch (err) {
      console.error("Database error:", err);
      setError(true);
      // Fallback to mock data so the site doesn't "break" during dev
      setHostels(mockHostels as any[] as Hostel[]);
    }
    setLoading(false);
  }

  useEffect(() => {
    fetchHostels();
  }, []);

  return (
    <main className="mx-auto max-w-7xl px-4 py-10 animate-fade-in">
      {/* HEADER & SEARCHBAR */}
      <div className="mb-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">Search Results</h1>
            <p className="text-slate-500 font-medium">
              {loading ? "Accessing database..." : `Found ${hostels.length} hostels available`}
            </p>
          </div>
          {error && (
            <div className="text-xs bg-amber-50 text-amber-600 px-3 py-1 rounded-lg border border-amber-100 font-bold">
              ⚠️ Database Offline: Showing Cached Data
            </div>
          )}
        </div>
        
        <Suspense fallback={<div className="h-20 animate-pulse bg-slate-200 rounded-2xl" />}>
          <div className="glass-header p-4 rounded-2xl shadow-sm border border-white/20">
            <SearchBar mode="results" />
          </div>
        </Suspense>
      </div>

      {/* RESULTS LOGIC */}
      {loading ? (
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-80 bg-slate-200 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : hostels.length > 0 ? (
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {hostels.map((h) => (
            <HostelCard key={h.id} hostel={h} />
          ))}
        </div>
      ) : (
        /* NO FOUND IN DATABASE STATE */
        <div className="flex flex-col items-center justify-center py-24 bg-white rounded-3xl border-2 border-dashed border-slate-200 text-center animate-slide-up">
          <div className="h-20 w-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mb-6">
            <SearchX size={40} />
          </div>
          <h2 className="text-2xl font-black text-slate-900">No Found in Database</h2>
          <p className="text-slate-500 max-w-xs mt-2 font-medium">
            We couldn't find any hostels matching your criteria in our records.
          </p>
          <div className="flex gap-4 mt-8">
            <Link href="/" className="btn-primary px-8 py-3 text-sm">
              Clear All Filters
            </Link>
            <button 
              onClick={() => window.location.reload()} 
              className="flex items-center gap-2 text-slate-600 font-bold text-sm hover:text-blue-600 transition"
            >
              <Database size={16} /> Refresh Connection
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

// --- SUB-COMPONENT: HOSTEL CARD ---
function HostelCard({ hostel: h }: { hostel: Hostel }) {
  return (
    <div className="hostel-card animate-slide-up group bg-white border rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all">
      <div className="aspect-[4/3] bg-slate-200 relative overflow-hidden">
         <div className="absolute inset-0 flex items-center justify-center bg-slate-100 text-slate-400 group-hover:scale-105 transition-transform duration-700 font-bold uppercase tracking-widest text-[10px]">
           Photo coming soon
         </div>
         <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-black uppercase text-blue-600 shadow-sm z-10">
            {h.campus}
         </div>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="font-black text-lg text-slate-900 group-hover:text-blue-600 transition-colors leading-tight">
            {h.name}
          </h3>
          <div className="text-right">
            <p className="text-blue-600 font-black text-xl leading-none">GHS {h.price}</p>
            <p className="text-[9px] text-slate-400 uppercase tracking-tighter font-black mt-1">Per Semester</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-6 font-bold">
           <span className="capitalize px-2 py-1 bg-slate-100 rounded-md">{h.gender}</span>
           <span>•</span>
           <span className="flex items-center gap-1"><MapPin size={12}/> {h.city || "Ghana"}</span>
        </div>
        
        <Link 
          href={`/hostel/${h.id}`} 
          className="btn-primary w-full py-4 text-sm font-black uppercase tracking-widest shadow-lg shadow-blue-100"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}