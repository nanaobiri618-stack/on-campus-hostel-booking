// app/search/types.ts
export type SearchQuery = {
  campus?: string;
  min?: number;
  max?: number;
  gender?: "female" | "male" | "mixed" | "" | string;
  date?: string; // future use
};

export type Hostel = {
  id: string;
  slug: string;
  name: string;
  campus: string;
  city: string;
  price: number; // GHS / semester
  gender: "female" | "male" | "mixed";
  verified: boolean;
};