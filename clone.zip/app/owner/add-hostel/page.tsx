"use client";
import React, { useState } from "react";
import { Upload, Home, MapPin, BadgeCheck, DollarSign } from "lucide-react";

export default function AddHostelPage() {
  const [formData, setFormData] = useState({
    name: "",
    campus: "KNUST",
    location: "",
    price: "",
    rooms: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Here you will call your API route to save to MySQL
    console.log("Saving to Database...", formData);
  };

  return (
    <main className="min-h-screen bg-slate-50 py-12 px-4">
      <div className="auth-card !max-w-2xl">
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-black text-slate-900">List Your Hostel</h1>
          <p className="text-slate-500">Provide accurate details for student verification.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 ml-2">Hostel Name</label>
              <input type="text" placeholder="e.g. Evandy Hostel" required 
                onChange={(e) => setFormData({...formData, name: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 ml-2">Campus Affiliation</label>
              <select onChange={(e) => setFormData({...formData, campus: e.target.value})}>
                <option value="">Select a Campus</option>
                <option value="KNUST">KNUST (Kumasi)</option>
                <option value="UG">University of Ghana (Legon)</option>
                <option value="UCC">University of Cape Coast</option>
                <option value="UDS">UDS (Tamale/Wa/Navrongo)</option>
                <option value="UPSA">UPSA (Accra)</option>
                <option value="UEW">UEW (Winneba)</option>
                <option value="GIMPA">GIMPA</option>
                <option value="UMaT">UMaT (Tarkwa)</option>
                <option value="ATU">ATU (Accra)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold uppercase text-slate-400 ml-2">Location Address</label>
            <input type="text" placeholder="e.g. Ayeduase Gate, Kumasi" required 
              onChange={(e) => setFormData({...formData, location: e.target.value})} />
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 ml-2">Price (GH₵ / Year)</label>
              <input type="number" placeholder="3500" required 
                onChange={(e) => setFormData({...formData, price: e.target.value})} />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-slate-400 ml-2">Rooms Available</label>
              <input type="number" placeholder="12" required 
                onChange={(e) => setFormData({...formData, rooms: e.target.value})} />
            </div>
          </div>

          <button type="submit" className="btn-primary w-full py-4 text-lg">
            <Upload className="mr-2" size={20} /> List Hostel Now
          </button>
        </form>
      </div>
    </main>
  );
}