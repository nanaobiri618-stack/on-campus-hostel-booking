"use client";
import React, { useState } from "react";
import Link from 'next/link';
import { 
  CheckCircle, 
  Bell, 
  Smartphone, 
  UserCheck, 
  Search, 
  ShieldCheck, 
  CreditCard,
  LayoutDashboard,
  Home,
  Users,
  Settings,
  LogOut,
  TrendingUp,
  Clock,
  Menu,
  Plus,
  BarChart3
} from "lucide-react";

export default function OwnerDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const bookings = [
    { id: 1, student: "Akosua Mensah", code: "HOS-7721", amount: "3,200", status: "Paid", method: "MTN MoMo", time: "Just now" },
    { id: 2, student: "Kwame Boateng", code: "HOS-9012", amount: "2,500", status: "Pending", method: "Telecel Cash", time: "15 mins ago" },
    { id: 3, student: "Abena Serwaa", code: "HOS-1102", amount: "2,900", status: "Paid", method: "MTN MoMo", time: "3 hours ago" },
  ];

  return (
    <div className="flex min-h-screen bg-slate-50">
      {/* --- SIDEBAR --- */}
      <aside className="bg-slate-900 text-white w-64 hidden lg:flex flex-col transition-all p-6">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="h-10 w-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900">
            <Home size={22} className="text-white" />
          </div>
          <span className="text-xl font-black tracking-tighter">HostelHub</span>
        </div>

        <nav className="flex-1 space-y-2">
          <NavItem icon={<LayoutDashboard size={20} />} label="Console" active />
          <NavItem icon={<Users size={20} />} label="Students" />
          <NavItem icon={<CreditCard size={20} />} label="Payments" />
          <NavItem icon={<Settings size={20} />} label="Settings" />
        </nav>

        <button className="mt-auto flex items-center gap-3 px-4 py-3.5 text-slate-400 hover:text-white transition-colors font-bold">
          <LogOut size={20} /> Logout
        </button>
      </aside>

      {/* --- MAIN CONTENT --- */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="glass-header px-6 py-4 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b">
          <h2 className="text-lg font-bold text-slate-800 uppercase tracking-wider text-xs">Owner Administration</h2>
          <div className="flex items-center gap-4">
            <button className="relative p-2.5 bg-white border border-slate-200 rounded-full shadow-sm">
              <Bell size={20} className="text-slate-600" />
              <span className="absolute top-2 right-2 h-2.5 w-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
            </button>
            <div className="h-10 w-10 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-white font-black">OA</div>
          </div>
        </header>

        <div className="p-6 lg:p-10 space-y-8 animate-fade-in">
          
          {/* Top Title Section with THE MISSING BUTTON */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-black text-slate-900 tracking-tight">Welcome Back!</h1>
              <p className="text-slate-500 font-medium">Manage your properties and real-time student verification.</p>
            </div>
            
            <Link 
              href="/owner/add-hostel" 
              className="flex items-center gap-2 bg-blue-600 text-white px-6 py-4 rounded-2xl font-bold hover:bg-blue-700 transition shadow-xl shadow-blue-200 active:scale-95"
            >
              <Plus size={20} /> Add New Hostel
            </Link>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard label="Total Revenue" value="GH₵ 15,700" icon={<Smartphone />} color="blue" />
            <StatCard label="Verified Today" value="12 Students" icon={<UserCheck />} color="green" />
            <StatCard label="Total Bookings" value="24" icon={<BarChart3 />} color="amber" />
          </div>

          {/* Feed Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-200 mt-4">
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="text-blue-600" size={24} />
              Recent Applications
            </h2>
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Search Verification Code..." 
                className="pl-10 h-11 w-full sm:w-72 rounded-xl border-slate-200 focus:ring-blue-500" 
              />
            </div>
          </div>

          {/* List Feed */}
          <div className="space-y-4">
            {bookings.map((item) => (
              <div key={item.id} className="auth-card !max-w-none p-6 flex flex-col lg:flex-row items-center justify-between gap-6 hover:border-blue-200 transition-all animate-slide-up group bg-white border rounded-2xl shadow-sm">
                <div className="flex items-center gap-5 w-full lg:w-auto">
                  <div className="h-16 w-16 rounded-2xl bg-slate-900 flex items-center justify-center text-white font-bold text-2xl shadow-xl shadow-slate-200 group-hover:bg-blue-600 transition-colors">
                    {item.student[0]}
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-lg leading-tight">{item.student}</h3>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className={`text-[10px] font-black px-2.5 py-1 rounded-md uppercase tracking-tight ${item.status === 'Paid' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                        {item.status}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">• {item.time} via {item.method}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col md:flex-row items-center gap-6 w-full lg:w-auto">
                  <div className="bg-slate-50 px-8 py-3 rounded-2xl border border-slate-100 text-center w-full md:w-auto">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Unique Code</p>
                    <p className="text-2xl font-mono font-black text-blue-700 tracking-[0.2em]">{item.code}</p>
                  </div>
                  <button className="btn-primary w-full md:w-auto px-10 py-4 flex gap-2 shadow-blue-300">
                    <ShieldCheck size={20} /> Verify Student
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

// Helper Components
function NavItem({ icon, label, active = false }: any) {
  return (
    <button className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all font-bold text-sm ${active ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}>
      {icon} {label}
    </button>
  );
}

function StatCard({ label, value, icon, color }: any) {
  const accent = color === 'blue' ? 'border-l-blue-600' : color === 'green' ? 'border-l-green-600' : 'border-l-amber-600';
  const iconBg = color === 'blue' ? 'bg-blue-50 text-blue-600' : color === 'green' ? 'bg-green-50 text-green-600' : 'bg-amber-50 text-amber-600';

  return (
    <div className={`bg-white p-6 border-l-4 rounded-2xl shadow-sm border ${accent} hover:shadow-xl transition-shadow flex items-center gap-5`}>
      <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${iconBg}`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{label}</p>
        <p className="text-2xl font-black text-slate-900">{value}</p>
      </div>
    </div>
  );
}