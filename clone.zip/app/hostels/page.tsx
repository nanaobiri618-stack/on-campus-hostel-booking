export default function HostelsPage() {
  return <h1 className="p-10 text-2xl">Student View: Available Hostels</h1>;
}